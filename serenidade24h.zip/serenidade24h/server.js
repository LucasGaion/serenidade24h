import dotenv from 'dotenv';
dotenv.config();

import express from 'express'
import bodyParser from 'body-parser';
import chatController from './src/controller/chatController.js';

const app = express();
const PORT = process.env.PORT;

app.use(bodyParser.json());
app.use(express.static('public'));

// Rota para receber mensagens do usuário
app.post('/api/message', chatController.handleUserMessage);

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
