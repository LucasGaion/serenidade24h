document.getElementById('sendButton').addEventListener('click', async () => {
    const userInput = document.getElementById('userInput').value;

    // Adiciona a mensagem do usuário ao chat log dentro da caixa de mensagem
    document.getElementById('chatLog').innerHTML += `<div class="message user"><strong>Você:</strong> ${userInput}</div>`;

    // Envia a mensagem para o backend
    const response = await fetch('/api/message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: userInput })
    });

    if (response.ok) {
        const data = await response.json();
        document.getElementById('chatLog').innerHTML += `<div class="message bot"><strong>Serenidade:</strong> ${data.reply}</div>`;
    } else {
        const errorText = await response.text(); 
        document.getElementById('chatLog').innerHTML += `<div class="message bot"><strong>Serenidade:</strong> Erro: ${errorText}</div>`;
    }

    document.getElementById('userInput').value = ''; 
});
