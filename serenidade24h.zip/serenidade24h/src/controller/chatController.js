import fetch from 'node-fetch';

const handleUserMessage = async (req, res) => {
    const userMessage = req.body.message;

    // Configuração do modelo
    const generationConfig = {
        temperature: 1,
        top_p: 0.95,
        top_k: 64,
        max_output_tokens: 8192,
        response_mime_type: "text/plain"
    };

    try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [
                    {
                        parts: [
                            {
                                text: userMessage // Mensagem do usuário
                            }
                        ]
                    }
                ],
                generation_config: generationConfig // Configurações de geração
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("Erro na API:", errorData);
            return res.status(response.status).json(errorData);
        }

        const data = await response.json();
        
        // Log da resposta completa para depuração
        console.log("Resposta da API:", JSON.stringify(data, null, 2));

        // Verificando a nova estrutura da resposta
        if (data.candidates && data.candidates.length > 0 && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts.length > 0) {
            const botMessage = data.candidates[0].content.parts[0].text; // Mensagem do bot
            res.json({ reply: botMessage });
        } else {
            console.error("Estrutura inesperada na resposta da API:", data);
            res.status(500).json({ error: 'Estrutura inesperada na resposta da API' });
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
        res.status(500).json({ error: 'Erro ao processar a mensagem' });
    }
};

// Exportando como padrão
export default { handleUserMessage };
